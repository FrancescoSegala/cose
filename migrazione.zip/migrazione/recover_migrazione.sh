echo "recovering migrazione"



for i in {0..255}
do
    pattern=$(printf "%02x" $i)
    cp  *.json $pattern/
    rm -f $pattern/stop.txt
done
