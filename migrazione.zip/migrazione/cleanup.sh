echo "cleaning up"
rm init_migrazione.txt
for i in {0..255}
do
    pattern=$(printf "%02x" $i)
    rm -rf $pattern
    echo "removed folder $pattern"
done
