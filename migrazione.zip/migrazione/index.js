var got = require( 'got' )
const FormData = require( 'form-data' );
const fs = require( 'fs' );

var id = process.argv[2]
var config = JSON.parse(fs.readFileSync('config_pod_preprod.json', 'utf8'))
var READ_PRECALL_URL=config.READ_PRECALL_URL
var DMS_URL= config.DMS_URL
var grant_type=config.grant_type
var client_id=config.client_id
var client_secret=config.client_secret
var user=config.user

var config_subfolders =  JSON.parse(fs.readFileSync('config_subfolders.json', 'utf8'))
var subfolders = config_subfolders.subfolders
var non_migrare = config_subfolders.non_migrare

function log( m ) {
    console.log( new Date().toISOString() + " " + id + " " + m )
}

function fail( m, doc, reason ) {
    console.log( new Date().toISOString() + " " + id + " " + "FAIL" + " " + m )

	reason = reason.replace("/","")
	if (reason.length>63) {
		reason = reason.substring(63)
	}

	if (doc && reason) {
		fs.mkdirSync("scartati/"+reason, {recursive: true})
		fs.writeFileSync("scartati/"+reason+"/"+id+'.json', JSON.stringify(doc,null,4), 'utf-8')
		if (fs.existsSync("tmp/scaricato_da_dds")) {
			let extension = doc.contents[0].contentsName.substring(doc.contents[0].contentsName.lastIndexOf('.'))
			fs.renameSync("tmp/scaricato_da_dds", "scartati/"+reason+"/"+id+extension)
		}
	}

    process.exit( 1 )
}

function find( list, k ) {
    return list.find( e => e.key == k ) ? list.find( e => e.key == k ) : {
        value: ""
    }
}

function info( list ) {
    return list.reduce( ( r, e ) => {
        let v = e.value.$date || e.value
        r[ translate( e.key ) ] = v;
        return r;
    }, {} )
}

function translate( k ) {
    return {
        'LineaREMI': 'linea',
        'CodiceRemi': 'remi'

    } [ k ] || k
}

function name( r, doc ) {
    //format per nome del documento e degli allegati : remi-linea-yyyymmdd-uuid-filename[0,10].extension
    let filename = doc.contents[0].contentsName.replace(/' '/g, '').substring(0,10)
    let extension = doc.contents[ 0 ] ? "." + doc.contents[ 0 ].contentsId.split( '.' )[ doc.contents[ 0 ].contentsId.split( '.' ).length - 1 ] : ''
    return ( r.info[ 0 ].remi ? r.info[ 0 ].remi + '-' : '' ) +
        ( r.info[ 0 ].linea ? r.info[ 0 ].linea + '-' : '' ) +
        ( r.published_at ? r.published_at.substring( 0, 10 ).replace(/-/g, ''): "" ) +
        '-' + r.subfolders[ 0 ] +
        '-' + Math.random().toString( 36 ).substring( 2, 9 ).toUpperCase() + 'MIGR-' +
        filename +
        extension
}

async function at( precall ) {
    let access_token = await cache( 'access_token', () => post( precall.SSOUrl ) )
    let token = access_token.access_token.split( '.' )[ 1 ]
    let exp = JSON.parse( Buffer.from( token, 'base64' ).toString() ).exp

    if ( new Date().getTime() / 1000 > exp ) {
        log( "access token scaduto..." )
        fs.unlinkSync( 'tmp/access_token.txt' )
        access_token = await cache( 'access_token', () => post( precall.SSOUrl ) )
    }

    return access_token
}


async function get( url ) {
    let options = {
        searchParams: {
            grant_type: grant_type,
            client_id: client_id,
            client_secret: client_secret
        },
        https: {
            'rejectUnauthorized': false
        },
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    }
    return JSON.parse( ( await got.get( url, options ) ).body )
}

async function post( url ) {
    let options = {
        form: {
            grant_type: grant_type,
            client_id: client_id,
            client_secret: client_secret
        },
        https: {
            'rejectUnauthorized': false
        },
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    }
    return JSON.parse( ( await got.post( url, options ) ).body )
}

async function post_json( url, body, access_token ) {
    let options = {
        https: {
            'rejectUnauthorized': false
        },
        headers: {
            'OAM_REMOTE_USER': user,
            'Authorization': "Bearer " + access_token
        },
        json: body
    }
    return JSON.parse( ( await got.post( url, options ) ).body )
}


async function download( url, body, access_token, filename ) {
    let options = {
        https: {
            'rejectUnauthorized': false
        },
        headers: {
            'OAM_REMOTE_USER': user,
            'Authorization': "Bearer " + access_token
        },
        json: body
    }
    fs.writeFileSync('tmp/allegati/'+filename, await got.post( url, options ).buffer(), 'ascii' )
}

async function upload(url , document, filename){
    let form = new FormData()
    form.append('document', document )
    form.append('file', fs.createReadStream('tmp/allegati/'+filename))

    let options = {
        https: {
            'rejectUnauthorized': false
        },
        headers: {
            'Content-Type': null,
            'Authorization': "Bearer " + config.access_token
        },
        body: form
    }
    return JSON.parse( ( await got.post( url, options ) ).body )
}

async function upload_allegato(url, form) {
    let options = {
        https: {
            'rejectUnauthorized': false
        },
        headers: {
            //'Content-Type': null,
            'Authorization' : 'Bearer ' + config.access_token
        },
        body: form
    }
    return JSON.parse( ( await got.post( url, options ) ).body )
}

async function cache( nome, f ) {
    let result = {}

    if ( fs.existsSync( 'tmp/' + nome + '.txt' ) ) {
        log( nome + " [file] ..." )
        result = JSON.parse( fs.readFileSync( 'tmp/' + nome + '.txt', 'utf-8' ) )

    } else {
        log( nome + " [rete]..." )
        try {
            result = await f()
            fs.writeFileSync( 'tmp/' + nome + '.txt', JSON.stringify( result, 'utf-8' ) )
        } catch ( e ) {
            fail( 'Errore in ' + nome + e )
        }
    }
    return result
}

function attachment_form(doc) {
    let form = new FormData()
    for (index=1; index<doc.contents.length; index+=1) {
        let content_name = doc.contents[index].contentsName
        form.append('file', fs.createReadStream('tmp/allegati/'+doc.contents[index].contentsName))
        if (content_name.length>36 && content_name.startsWith('_') && content_name.charAt(37) == '_') {
            form.append('original_id', content_name.substring(1,37))
        }
        //TODO stabilire cosa inserire nel caso non rispetti i 36 caratteri
        else {
           form.append('original_id', doc.contents[index].contentsId)
        }
    }
    return form
}

function resolve_subfolders(doc) {
    let subfolders = find(doc.customAttributes, 'Tipo').value != "" ? find(doc.customAttributes, 'Tipo').value : tdoc2lvl( doc.systemAttributes.documentClass )
    if (subfolders == 'VERB' && doc.systemAttributes.documentClass == 'OLDOC')  {
        return ['OLD_VERB']
    }

    for (index in subfolders) {
        if (config_subfolders.tdoc2lvl.hasOwnProperty(subfolders[index])) {
            subfolders[index] = config_subfolders.tdoc2lvl[subfolders[index]]
        }
    }

    return subfolders
}

function tdoc2lvl( documental_class ) {
    return [ config_subfolders.tdoc2lvl[ documental_class ] || documental_class ]
}

function published_at_resolve( doc ) {
    return find( doc.customAttributes, "DataDocumento" ).value.$date ||
        find( doc.customAttributes, "DataEmissione" ).value.$date ||
        find( doc.customAttributes, "DataEsecuzioneProva" ).value.$date ||
        find(doc.customAttributes, "ENTRATA_ESERCIZIO_DT").value.$date ||
		find(doc.customAttributes, "MeseAnno").value.$date
}

function published_by_resolve( doc ){
    return  find( doc.customAttributes, "CreatoDa" ).value
}

async function run() {

    fs.existsSync( 'tmp' ) || ( fs.mkdirSync( 'tmp' ) && log( "Creazione directory..." ) )
	fs.existsSync('tmp/scaricato_da_dds') && fs.unlinkSync('tmp/scaricato_da_dds')

    if (fs.existsSync('tmp/allegati')) {
        fs.readdirSync("tmp/allegati").forEach(file => {fs.unlinkSync('tmp/allegati/'+file)})
    }
    else {
        fs.mkdirSync('tmp/allegati')
    }
    let precall = await cache( 'precall', () => get( READ_PRECALL_URL ) )
    let access_token = await at( precall )

    log( "Metadati..." )
    let doc = {}
    try {
        doc = await post_json( precall.getdoc + '/getCompleteDocument', {
            "OS": config.OS,
            "id": id
        }, access_token.access_token )
    } catch ( e ) {
        log("Errore nel download dei metadati del documento: " + e)
        fail( "download metadati -"+ JSON.parse( e.response.body ).message )
    }

    if (non_migrare.includes(doc.systemAttributes.documentClass)) {
        log("OK documento non migrato: classe documentale: "+doc.systemAttributes.documentClass)
        process.exit(0)
    }

	if (doc.contents.length == 0 ){
        log("OK documento non migrato: nessun allegato presente")
        process.exit(0)
    }

    if (!/^[a-zA-Z0-9]+[a-zA-Z0-9_\-. àèòéìù<>]*$/.test(doc.systemAttributes.documentTitle)) {
        log("OK documento non migrato: titolo dell'allegato non accettabile")
        process.exit(0)
    }

	let DC = {
        "OS": config.OS,
        "id": id,
        "contentName": doc.contents[ 0 ] ? doc.contents[ 0 ].contentsName : ''
    }

    log( "Download..." )
    try {
        await download( precall.getdoc + '/getContentElements', DC, access_token.access_token, doc.contents[0].contentsName )
    } catch ( e ) {
        log("Errore nel download del file principale: " + e)
        fail( "download fallito - " + JSON.parse( e.response.body ).reason)
    }

    if (doc.contents.length > 1) {
        log( "Download allegati..." )
        for (index=1; index<doc.contents.length; index+=1) {

            let name = doc.contents[index].contentsName
            let DC = {
                "OS": config.OS,
                "id": id,
                "contentName": name
            }
            try {
                await download( precall.getdoc + '/getContentElements', DC, access_token.access_token, name )
            } catch ( e ) {
                log("Errore nel download di un allegato: " + e)
                fail( "download allegato fallito - " + JSON.parse( e.response.body ).reason)
            }
        }
    }

    let folder = subfolders[tdoc2lvl( doc.systemAttributes.documentClass )[0]] || doc.systemAttributes.foldersParents[0]
    if (! folder ){
        fail("classe documentale " + doc.systemAttributes.documentClass + " non rilevabile", doc, "classe_documentale_sconosciuta_"+doc.systemAttributes.documentClass)
    }

    let DOCUMENT = {
        "subfolders":  resolve_subfolders(doc),
        "published_by": !published_by_resolve(doc) ? "MIGRAZIONE" : published_by_resolve(doc),
        "notes": find( doc.customAttributes, "Note" ).value || "",
        "published_at": !published_at_resolve(doc) ? new Date().toISOString() : published_at_resolve(doc),
        "info": [ info( doc.customAttributes ) ],
        "status": find( doc.customAttributes, "StatoDocumento" ).value == 'Pubblicato' ? 'active' : 'inactive',
        "title": doc.systemAttributes.documentTitle.length > 0 ? doc.systemAttributes.documentTitle : null,
        "original_id": doc.systemAttributes.versionSeriesId,
        "cache": true
    }

    DOCUMENT.name = name( DOCUMENT, doc )
    DOCUMENT.info[ 0 ].content_name = doc.contents[ 0 ] ? doc.contents[ 0 ].contentsName : ''
    DOCUMENT.info[ 0 ].dds_id_contenitore = doc._id

    let doc_ids = null
    log( "Upload..." )
    try {
        docs = await upload( DMS_URL + "/documents", JSON.stringify(DOCUMENT), DOCUMENT.info[0].content_name)
        if (docs.length > 1) {
            fs.mkdirSync("multipli_doc/"+id, {recursive: true})
            for (d in docs) {
                fs.writeFileSync("multipli_doc/"+id+"/"+docs[d].id+'.json', JSON.stringify(docs[d],null,4), 'utf-8')
            }
        }
        log("Creato documento: " + docs.map( e => e.id ).join( ',' ))
        doc_ids = docs.map(e => e.id)

    }
    catch ( e ) {
        log("Errore nel upload del file: " + e)
        let m = JSON.parse( e.response.body ).message
        if (Array.isArray(m)) m=m[0]
            fail( "upload fallito - " + m, doc, m.trim().split(' ').join('_').split(':').join('_'))
    }

    if (doc.contents.length > 1) {
        log("Upload allegati...")
        try {
            for (d in doc_ids) {
                await upload_allegato( DMS_URL + "/documents/"+doc_ids[d]+"/attachments", attachment_form(doc))
            }
        } catch ( e ) {
            log("Errore nel upload di un allegato: " + e)
            fail(JSON.parse( e.response.body ).message)
        }
    }
    log("OK Documento importato")
}

run()
