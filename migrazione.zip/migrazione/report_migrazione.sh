for i in {0..255}
do
pattern=$(printf "%02x" $i)
cp $patter/migrazione.log storico_migrazioni/migrazione10k/migrazione_$pattern.log
done


