for i in $(seq 0 255)
do
pattern=$(printf "%02x" $i)
touch $pattern/stop.txt
done