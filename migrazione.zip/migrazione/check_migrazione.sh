clear
echo -e "lotto \t\t macchina \t\t avanzamento \t OK \t FAIL \t Da Riprocessare \t duplicati"
tot_documenti_ok=0
tot_documenti_fail=0
tot_documenti_elaborati=0

for i in {0..255}
    do
    pattern=$(printf "%02x" $i)

    if [ -f $pattern/migrazione.log ]
        then
            start=$(date +%s -r $pattern/migrazione.log)
            now=$(date +%s)
            if [ $(expr $now - $start) -gt 60 ]
            then
                echo -e " \033[0;35m  trovato lotto $pattern sospeso "
                echo -e "\033[1;37m"
            fi
            tot_documenti_ok=$(expr $tot_documenti_ok + $(grep -c 'OK' $pattern/migrazione.log))
            tot_documenti_fail=$(expr $tot_documenti_fail + $(grep -c 'FAIL' $pattern/migrazione.log))
            tot_documenti_elaborati=$(expr $tot_documenti_elaborati + $(awk '{print $2}' $pattern/migrazione.log | sort | uniq | wc -l))
    fi

    if [ -f $pattern/end.txt ]
        then
        importati=$(grep "OK Documento importato" $pattern/migrazione.log  | awk '{print $2}' | sort | uniq | wc -l)
        non_migrati=$(grep "OK documento non migrato" $pattern/migrazione.log | awk '{print $2}' | sort | uniq | wc -l )

        grep "OK Documento importato" $pattern/migrazione.log | awk '{print $2}' | sort | uniq -D | uniq > $pattern/duplicati.txt
        duplicati_tot=$(cat $pattern/duplicati.txt | wc -l )

        scartati=$(grep  "FAIL" $pattern/migrazione.log | awk '{print $2}' | sort | uniq | wc -l )
        tot_originale=$(wc -l < $pattern/docs_to_migrate.txt)
        tot=$(expr $importati + $non_migrati + $scartati)
        start_time=$(date -d $(awk '{print $1}' $pattern/migrazione.log | head -1) +%s )
        end_time=$(date -d $(awk '{print $1}' $pattern/migrazione.log | tail -1) +%s )
        duration=$(expr $end_time - $start_time)
        rapporto=$(expr $tot \* 60)
        rapporto=$(expr $rapporto / $duration)

        echo -e "\033[1;37m lotto $pattern: $importati/$non_migrati ok/pass in $duration sec , $rapporto doc/min  da $(cat $pattern/start.txt)"
        if [ $scartati -gt 0 ]
        then
            echo -e "\033[1;33m lotto $pattern - scartati : $scartati"
        fi
        if [ ! $(expr $tot_originale - $tot) == 0 ]
        then
            echo -e "\033[0;31m  lotto $pattern: $(expr $tot_originale - $tot) non classificati correttamente, duplicati : $duplicati_tot"
        fi
    fi
    if [ -f $pattern/start.txt ] && [ ! -f $pattern/end.txt ]
    then
        m=$(cat $pattern/start.txt)
        tot=$(wc -l < $pattern/docs_to_migrate.txt)
        ok=$(grep -c 'OK' $pattern/migrazione.log)
        ko=$(grep -c 'FAIL' $pattern/migrazione.log)
        elaborati=$(awk '{print $2}' $pattern/migrazione.log | sort | uniq | wc -l)
        pass=$(expr $elaborati - $ok - $ko)
        duplicati=$(grep "OK" $pattern/migrazione.log | awk '{print $2}' | sort | uniq -D | uniq | wc -l )
        colore=$( [ $(expr $i % 2) -eq 0 ] && echo "36m" || echo "37m" )

        echo -e "\033[1;$colore $pattern \t $m \t $elaborati/$tot \t $ok \t $ko \t $pass \t $duplicati"
	fi
done

echo -e "\033[1;37m"


echo migrazione completata al: $(echo $tot_documenti_elaborati $(wc -l docs_to_migrate.txt) | awk ' { print $1 *100 / $2 }') %
echo totale documenti ok: $tot_documenti_ok, totale documenti fail: $tot_documenti_fail, totale documenti elaborati: $tot_documenti_elaborati
