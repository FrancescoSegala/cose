
var got = require( 'got' )
const FormData = require( 'form-data' );
const fs = require( 'fs' );

var config = JSON.parse(fs.readFileSync('config_local.json', 'utf8'))
var READ_PRECALL_URL=config.READ_PRECALL_URL
var WRITE_PRECALL_URL= config.WRITE_PRECALL_URL
var grant_type=config.grant_type
var client_id=config.client_id
var client_secret=config.client_secret
var user=config.user

var id = '[delete-documenti]'

function log( m ) {
    console.log( new Date().toISOString() + " " + id + " " + ((typeof(m)=='object') ? JSON.stringify(m, null, 4) : m ))
}

function fail( m, doc, reason ) {
    console.log( new Date().toISOString() + " " + id + " " + "FAIL" + " " + m )

	if (doc && reason) {
		fs.mkdirSync("scartati/"+reason, {recursive: true})
		fs.writeFileSync("scartati/"+reason+"/"+id+'.json', JSON.stringify(doc,null,4), 'utf-8')
		if (fs.existsSync("tmp/scaricato_da_dds")) {
			let extension = doc.contents[0].contentsName.substring(doc.contents[0].contentsName.lastIndexOf('.'))
			fs.renameSync("tmp/scaricato_da_dds", "scartati/"+reason+"/"+id+extension)
		}
	}

    process.exit( 1 )
}

async function get( url ) {
    let options = {
        searchParams: {
            grant_type: grant_type,
            client_id: client_id,
            client_secret: client_secret
        },
        https: {
            'rejectUnauthorized': false
        },
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    }
    return JSON.parse( ( await got.get( url, options ) ).body )
}

async function post( url ) {
    let options = {
        form: {
            grant_type: grant_type,
            client_id: client_id,
            client_secret: client_secret
        },
        https: {
            'rejectUnauthorized': false
        },
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    }
    return JSON.parse( ( await got.post( url, options ) ).body )
}

async function post_json( url, body, access_token ) {
    let options = {
        https: {
            'rejectUnauthorized': false
        },
        headers: {
            'OAM_REMOTE_USER': user,
            'Authorization': "Bearer " + access_token
        },
        json: body
    }
    return JSON.parse( ( await got.post( url, options ) ).body ) 
}

async function run() {
    let tot = 0

    for (i = 0; i <256; i++) {
        let precall = await get( READ_PRECALL_URL ) 
        let precall_write = await get ( WRITE_PRECALL_URL )
        let access_token_get = await post( precall.SSOUrl ) 
        let access_token_write = await post( precall_write.SSOUrl )
        let delete_url = precall_write.deletedoc
        let get_doc_url = precall.getdoc 

        let hex_num = i.toString(16).length == 1 ? "0"+i.toString(16) : i.toString(16)
        let DMSMISv = 'DMSMIS_'+hex_num+'%'

        try {
            response = await post_json(get_doc_url+'/getDocumentBySQL', {
                "OS": "DMSMIS", 
                "select" : ["_id"], 
                "where" : " _id is not null and _id like '"+DMSMISv+"'"
            }, access_token_get.access_token)
        }
        catch (e) {
            log(e)
            fail(JSON.parse(e.response.body).message)
        }

        tot+=response.length
        log("Il numero di documenti trovati con iniziali "+ hex_num+ " e' di: "+ response.length)

        for (index in response) {
            let id_documento = response[index]._id
            
            try {
                response_delete = await post_json(delete_url + '/deleteDocument', {
                    "OS": "DMSMIS",
                    "id": id_documento,
                    "deleteAllVersion": true,
                }, access_token_write.access_token )
                log ("Eliminato documento: " + id_documento+ " ("+(parseInt(index)+1)+"/"+response.length+")")
            } catch ( e ) {
                log("Errore nel eliminazione del documento: " + e)
                fail( "errore download -"+ JSON.parse( e.response.body ).message )
            }
        }
    }
    log("TOT: " + tot)
}

run();