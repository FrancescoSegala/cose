
for i in $(seq 0 255)
do
pattern=$(printf "%02x" $i)
echo creazione cartella: $pattern
mkdir -p $pattern
grep -i {$pattern docs_to_migrate.txt > $pattern/docs_to_migrate.txt
#cp -r node_modules ./$pattern
cp config_local.json config_pod_preprod.json config_subfolders.json log-sender.js index.js migrazione.sh ./$pattern
done
touch init_migrazione.txt
