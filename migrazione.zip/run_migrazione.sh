cd /migrazione/migr

if [ ! -f init_migrazione.txt ]
then
    exit
fi

sleep $( expr $RANDOM % 60 )

for i in {0..255}
do
    pattern=$(printf "%02x" $i)
    if [ -f $pattern/start.txt ] && [ ! -f $pattern/end.txt ]
    then
        if [ -f $pattern/migrazione.log ]
        then
            start=$(date +%s -r $pattern/migrazione.log)
            now=$(date +%s)
            if [ $(expr $now - $start) -gt 60 ]
            then
                echo "trovato lotto sospeso "
                rm $pattern/start.txt
                exit
            fi
        fi

        if [ $( cat $pattern/start.txt | grep -c $(uname -n )) -ne 0 ]
        then
            echo "STO GIA LAVORANDO su $pattern"
            exit
        fi
    fi
done
echo "NON STO LAVORANDO"



for i in {0..255}
    do
    pattern=$(printf "%02x" $i)
    if [ ! -f $pattern/start.txt ]
    then
        dir=$pattern
        break
    fi
done


cd $dir
echo " Prendo in carico $PWD"
#./migrazione.sh
cd ..

