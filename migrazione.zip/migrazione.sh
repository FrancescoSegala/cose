echo $(uname -n) > start.txt
mkdir -p tmp

if [ -f migrazione.log ]
then
grep 'OK' migrazione.log | awk '{print $2}' > tmp/migrati.log
grep 'FAIL' migrazione.log | awk '{print $2}' >> tmp/migrati.log
sort tmp/migrati.log > tmp/migrati_sorted.log
sort docs_to_migrate.txt > tmp/docs_to_migrate_sorted.txt
comm -23 tmp/docs_to_migrate_sorted.txt tmp/migrati_sorted.log > tmp/da_migrare.txt
else
sort docs_to_migrate.txt > tmp/da_migrare.txt
fi
export NODE_PATH=../node_modules

for f in $(cat tmp/da_migrare.txt)
do
    if [ ! -f stop.txt ]
    then
        occ=$(grep "OK" migrazione.log | grep -c $f )
        if [$occ -eq 0 ]
        then
            timeout 1m node index.js $f >> migrazione.log 2>> errori_migrazione.log
        fi
    else
        exit
    fi
done
echo "FINITA MIGRAZIONE LOTTO" > end.txt

