var got = require( 'got' );
const FormData = require( 'form-data' );
const fs = require( 'fs' );

var access_token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJTVVBFUlVTRVIiLCJjb21wYW55SUQiOiIiLCJjb2dub21lIjoiIiwibm9tZSI6IiIsImV4cCI6MTczMDAzOTk0NywidXNlcklEIjoiU1VQRVJVU0VSIiwiaWF0IjoxNjM1NDMxOTQ3fQ.jpoCzyaoJA0tZvxd57kKxUc4qmxyrP1PX2VI4e4wG14"
var id = 'migrazione.log'
var machine_name = process.argv[2]
var folder = process.argv[3]

function log( m ) {
    console.log( new Date().toISOString() + " " + id + " " + m )
}

function fail( m, doc, reason ) {
    console.log( new Date().toISOString() + " " + id + " " + "FAIL" + " " + m )

	if (doc && reason) {
		fs.mkdirSync("scartati/"+reason, {recursive: true})
		fs.writeFileSync("scartati/"+reason+"/"+id+'.json', JSON.stringify(doc,null,4), 'utf-8')
		if (fs.existsSync("tmp/scaricato_da_dds")) {
			let extension = doc.contents[0].contentsName.substring(doc.contents[0].contentsName.lastIndexOf('.'))
			fs.renameSync("tmp/scaricato_da_dds", "scartati/"+reason+"/"+id+extension)
		}
	}

    process.exit( 1 )
}

async function upload(url , document){
    let form = new FormData()
    form.append('document', document )
    form.append('file', fs.createReadStream('migrazione.log'))

    let options = {
        https: {
            'rejectUnauthorized': false
        },
        headers: {
            'Content-Type': null,
            'Authorization': "Bearer " + access_token
        },
        body: form
    }
    return JSON.parse( ( await got.post( url, options ) ).body )
}

async function run() {
    let DOCUMENT = {
        "subfolders":  ["CESTINO"],
        "published_by": "admin",
        "subfolders": [ "ALTRO" ],
        "published_at": "2021-11-11T11:19:07.762Z",
        "info": [],
        "original_id":"log-"+machine_name+"-"+folder
    }

    log( "INIZIO INVIO LOG..." )
    log(JSON.stringify(DOCUMENT))
    try {
        docs = await upload( "http:localhost:8090/dms-misura-service/documents",JSON.stringify(DOCUMENT))
        doc_ids = docs.map(e => e.id)
        log("CREATO DOCUMENTO MIGRAZIONE LOG:"+ doc_ids)
    } 
    catch ( e ) {
        log("Errore nel upload del log: " + e)
        let m = JSON.parse( e.response.body ).message 
        fail(m)
    }

}

run()
